import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';

const Dashboard = () => {
  const [leaveBalance, setLeaveBalance] = useState(null);
  const [leaveHistory, setLeaveHistory] = useState([]);
  const navigate = useNavigate(); 
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('token'));
    axios.get(`http://localhost:5001/leaveBalances?userId=${user.id}`)
      .then(res => setLeaveBalance(res.data[0]));

    axios.get(`http://localhost:5001/leaveRequests?userId=${user.id}`)
      .then(res => setLeaveHistory(res.data));
  }, []);

  const handleLeaveRequest = () => {
    navigate('/leave-request'); 
  };

  return (
    <div className="container">
      <div className="leave-balance">
        <h2>Leave Balance</h2>
        <p>{leaveBalance?.totalLeaves - leaveBalance?.leavesTaken} days</p>
      </div>

      <h3>Leave History</h3>
      <ul className="leave-history">
        {leaveHistory.map(leave => (
          <li key={leave.id}>
            <span>{leave.startDate} to {leave.endDate}</span> - 
            <span className={`status ${leave.status.toLowerCase()}`}> {leave.status}</span>
          </li>
        ))}
      </ul>

      {/* Add Leave Request Button */}
      <button className="leave-request-btn" onClick={handleLeaveRequest}>
        Request Leave
      </button>
    </div>
  );
};

export default Dashboard;
