import React from 'react';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import './LeaveRequestForm.css';
import { useNavigate } from 'react-router-dom';

const LeaveRequestForm = () => {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    const user = JSON.parse(localStorage.getItem('token'));
    await axios.post('http://localhost:5001/leaveRequests', {
      userId: user.id,
      ...data,
      status: 'pending',
    });
    alert('Leave request submitted');
    navigate('/employee-dashboard');
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit(onSubmit)}>
        <input {...register('startDate')} type="date" placeholder="Start Date" />
        <input {...register('endDate')} type="date" placeholder="End Date" />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default LeaveRequestForm;
