import React from 'react';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css';  // Import the CSS file

const Login = () => {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    try {
      const res = await axios.get(`http://localhost:5001/users?username=${data.username}&password=${data.password}`);
      console.log(res.data);
      if (res.data.length > 0) {
        const user = res.data[0];
        localStorage.setItem('token', JSON.stringify(user));
        if (user.role === 'employee') {
          navigate('/employee-dashboard');
        } else {
          navigate('/manager-dashboard');
        }
      }
    } catch (error) {
      console.error('Login failed');
    }
  };

  return (
    <div className="login-container">
      <form onSubmit={handleSubmit(onSubmit)} className="login-form">
        <h2>Login</h2>
        <input {...register('username')} placeholder="Username" />
        <input type="password" {...register('password')} placeholder="Password" />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
