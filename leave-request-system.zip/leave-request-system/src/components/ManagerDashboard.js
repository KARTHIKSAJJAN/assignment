import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ManagerDashboard.css';

const ManagerDashboard = () => {
  const [leaveRequests, setLeaveRequests] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5001/leaveRequests?status=pending')
      .then(res => setLeaveRequests(res.data));
  }, []);

  const handleDecision = (id, status) => {
    axios.patch(`http://localhost:5001/leaveRequests/${id}`, { status });
    setLeaveRequests(leaveRequests.filter(req => req.id !== id));
  };

  return (
    <div className="manager-container">
      <h2>Pending Leave Requests</h2>
      <ul className="leave-requests">
        {leaveRequests.map(leave => (
          <li key={leave.id}>
            <span>{leave.startDate} to {leave.endDate}</span>
            <div>
              <button className="approve" onClick={() => handleDecision(leave.id, 'approved')}>Approve</button>
              <button className="reject" onClick={() => handleDecision(leave.id, 'rejected')}>Reject</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ManagerDashboard;
