package com.order.project.controller;

import com.order.project.dto.SalesRepresentativeDTO;
import com.order.project.dto.ProductDTO;
import com.order.project.service.SalesRepresentativeService;
import com.order.project.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private SalesRepresentativeService salesRepService;

    @Autowired
    private ProductService productService;

    // Add a Sales Representative
    @PostMapping("/sales-representative")
    public ResponseEntity<String> addSalesRepresentative(@RequestBody SalesRepresentativeDTO salesRep) {
        SalesRepresentativeDTO addedRep = salesRepService.addSalesRepresentative(salesRep);
        return ResponseEntity.ok("Sales Representative " + addedRep.getSalesRepresentativeName() + " added.");
    }

    // Add a Product
    @PostMapping("/product")
    public ResponseEntity<String> addProduct(@RequestBody ProductDTO product) {
        ProductDTO addedProduct = productService.addProduct(product);
        return ResponseEntity.ok("Product " + addedProduct.getProductDescription() + " added.");
    }
}
