package com.order.project.controller;

import com.order.project.dto.UserRequest;
import com.order.project.service.UserService;
import com.order.project.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    // Add User
    @PostMapping("/add-user")
    public ResponseEntity<String> addUser(@RequestBody UserRequest user) {
        userService.addUser(user);
        return ResponseEntity.ok("User " + user.getUserName() + " added.");
    }

    // Place Order (Basic example with userId and productId)
    @PostMapping("/place-order")
    public ResponseEntity<String> placeOrder(@RequestParam Long userId, @RequestParam Long productId) {
        orderService.placeOrder(userId, productId);
        return ResponseEntity.ok("Order placed by user ID " + userId + " for product ID " + productId);
    }
}
