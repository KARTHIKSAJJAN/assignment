package com.order.project.entity;

import javax.persistence.*;

@Entity
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;

    private String productDescription;

    private String categoryCode;

    private Double price;

    private int qoh;  // Quantity on Hand

}
