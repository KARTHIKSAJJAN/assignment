package com.order.project.entity;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class SalesRepresentative {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long salesRepresentativeId;

    private String salesRepresentativeName;

    private LocalDate dateOfJoining;

    private Double salary;

    private Long managerId;

    private String branchCode;


}
