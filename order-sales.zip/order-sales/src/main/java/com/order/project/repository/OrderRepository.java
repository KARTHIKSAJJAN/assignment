package com.order.project.repository;

public class OrderRepository {
    
}
