package com.order.project.service;

public interface OrderService {
    void placeOrder(Long userId, Long productId);
}
