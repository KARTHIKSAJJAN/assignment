package com.order.project.service;

import com.order.project.dto.ProductDTO;

public interface ProductService {
    ProductDTO addProduct(ProductDTO dto);
}
