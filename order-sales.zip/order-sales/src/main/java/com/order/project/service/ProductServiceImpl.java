package com.order.project.service;

import com.order.project.dto.ProductDTO;
import com.order.project.entity.Product;
import com.order.project.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public ProductDTO addProduct(ProductDTO dto) {
        Product product = new Product();
        product.setProductDescription(dto.getProductDescription());
        product.setCategoryCode(dto.getCategoryCode());
        product.setPrice(dto.getPrice());
        product.setQoh(dto.getQoh());

        product = productRepository.save(product);

        dto.setProductId(product.getProductId());
        return dto;
    }
}
