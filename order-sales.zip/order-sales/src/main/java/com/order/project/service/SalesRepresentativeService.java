package com.order.project.service;

import com.order.project.dto.SalesRepresentativeDTO;

public interface SalesRepresentativeService {
    SalesRepresentativeDTO addSalesRepresentative(SalesRepresentativeDTO dto);
}
