package com.order.project.service;

import com.order.project.dto.SalesRepresentativeDTO;
import com.order.project.entity.SalesRepresentative;
import com.order.project.repository.SalesRepresentativeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SalesRepresentativeServiceImpl implements SalesRepresentativeService {

    @Autowired
    private SalesRepresentativeRepository salesRepRepository;

    @Override
    public SalesRepresentativeDTO addSalesRepresentative(SalesRepresentativeDTO dto) {
        SalesRepresentative salesRep = new SalesRepresentative();
        salesRep.setSalesRepresentativeName(dto.getSalesRepresentativeName());
        salesRep.setDateOfJoining(dto.getDateOfJoining());
        salesRep.setSalary(dto.getSalary());
        salesRep.setManagerId(dto.getManagerId());
        salesRep.setBranchCode(dto.getBranchCode());

        salesRep = salesRepRepository.save(salesRep);

        dto.setSalesRepresentativeId(salesRep.getSalesRepresentativeId());
        return dto;
    }
}
