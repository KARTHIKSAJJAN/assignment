package com.order.project.service;

import com.order.project.dto.UserRequest;

public interface UserService {
    UserRequest addUser(UserRequest userRequest);
}
