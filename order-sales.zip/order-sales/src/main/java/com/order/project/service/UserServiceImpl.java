package com.order.project.service;

import com.order.project.dto.UserRequest;
import com.order.project.entity.User;
import com.order.project.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void addUser(UserRequest userRequest) {
        User user = new User();
        user.setUserName(userRequest.getUserName());
        user.setContactNo(userRequest.getContactNo());
        user.setAddress(userRequest.getAddress());
        userRepository.save(user);
    }
}
